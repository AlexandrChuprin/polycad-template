
export class Addition {
    /** Выбрана ли опция */
    public checked = false;
    /***/
    constructor(
        public id: string,
        public type: string,
        public name: string,
        public image: string
    ) {

    }
}
