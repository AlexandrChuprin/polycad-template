
export class ProductionType {
    public isSelected = false;
    /***/
    constructor(
        public name: string,
        public image: string,
        public idtemplate: string,
    ) {

    }
}
